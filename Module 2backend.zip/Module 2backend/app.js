// app.js

// Importing mathFunctions module
const mathFunctions = require('./mathFunctions');

// Using the functions
console.log("Sum:", mathFunctions.sum(5, 3));
console.log("Multiplication:", mathFunctions.multiply(5, 3));
console.log("Division:", mathFunctions.divide(10, 2));
console.log("Subtraction:", mathFunctions.subtract(5, 3));
